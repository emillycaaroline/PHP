<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Page Title</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='main.css'>
    <script src='main.js'></script>
</head>
<body>
    <?php
    $time="Corinthians";
    $ano=1910;
    $frase1="Neo Química Arena";
    $frase2="10 de maio de 2014";

    echo "O $time fundado em $ano, com sua arena $frase1 fundado em $frase2";
    ?>
</body>
</html>